#!/system/xbin/bash

/system/xbin/busybox --install -s /system/xbin/

/system/xbin/chmod 0755 busybox
/system/xbin/chmod 0755 bash

echo "Чистим следы"

rm /system/xbin/install.sh